var Colors = "FFFFFF"; //Change color of entire widget
var Opacity = 1.0; //Change opacity of widget. Set between 0.0 and 1.0
