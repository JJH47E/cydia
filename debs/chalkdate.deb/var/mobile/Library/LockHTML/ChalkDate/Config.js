var MainColor = "ffffff"; //Enter a hex value in the form "ffffff"
var Opacity = "1.0"; //Enter a value between 0-1.0 to set the opacity (BETA)
