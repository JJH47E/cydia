# Chalk
A minimalist clock widget for XenHTML.

# How do I use it?
In order to use Chalk, you must have a jailbroken iOS device with XenHTML and XenInfo installed.

Once you have these, just place the master folder into /var/mobile/Library/LockHTML using Filza/iFile.

# Can I just install it through Cydia/Sileo?
I have plans to host a repo in future, but for now, this is the only way to install the widget.

Please follow me on Twitter [@Orange_Themes](https://twitter.com/orange_themes)
