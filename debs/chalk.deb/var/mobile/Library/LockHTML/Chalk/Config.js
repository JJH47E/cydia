var ClockColor = "ffffff"; //Please enter a hex value in the "ffffff" format
var MinuteColor = "ffffff"; //Please enter a hex value in the "ffffff" format
var MinuteOpacity = "1.0"; //Please enter a value between 0 and 1.0 (BETA)
var ClockOpacity = "1.0"; //Please enter a value between 0 and 1.0 (BETA)
